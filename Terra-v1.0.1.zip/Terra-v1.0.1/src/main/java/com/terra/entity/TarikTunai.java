package com.terra.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
public class TarikTunai {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "tariktunai_generator")
    @Column(name = "id_tarik_tunai")
    private long idtariktunai;

    @Column(name = "nik_karyawan")
    private long nikkaryawan;

    @Column(name = "jumlah_tarik")
    private double jumlahtarik;

    @Column(name = "tanggal_tarik")
    private LocalDateTime tanggaltarik;

    @Column(name = "no_rekening")
    private long norek;

}
