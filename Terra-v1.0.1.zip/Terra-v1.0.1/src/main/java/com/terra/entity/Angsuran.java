package com.terra.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
public class Angsuran {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "angsuran_generator")
    @Column(name = "id_angsuran")
    private long idangsuran;

    @Column(name = "no_pembiayaan")
    private long noPembiayaan;

    @Column(name = "id_pembiayaan")
    private long idpembiayaan;

    @Column(name = "bayar_angsuran")
    private double bayarangsuran;

    @Column(name = "tanggal_cicilan")
    private LocalDateTime tanggalcicilan;

    @Column(name = "nikKaryawan")
    private long nikkaryawan;

}
