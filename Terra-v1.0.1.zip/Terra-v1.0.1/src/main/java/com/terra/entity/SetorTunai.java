package com.terra.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
public class SetorTunai {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "setortunai_generator")
    @Column(name = "id_setor_tunai")
    private long idsetortunai;

    @Column(name = "nik_karyawan")
    private long nikkaryawan;

    @Column(name = "jumlah_setor")
    private double jumlahsetor;

    @Column(name = "tanggal_setor")
    private LocalDateTime tanggalsetor;

    @Column(name = "no_rekening")
    private long norek;

}
