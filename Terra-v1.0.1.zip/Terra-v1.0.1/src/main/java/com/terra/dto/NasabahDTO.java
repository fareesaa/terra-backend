package com.terra.dto;

import com.terra.entity.SetorTunai;
import com.terra.entity.TarikTunai;
import com.terra.repository.SetorTunaiRepository;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.swing.text.TabableView;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class NasabahDTO {

    private String nama;

    private long nikKtp;

    private String email;

    private String password;

    private String noHP;

    private String pekerjaan;

    private String alamat;

    private int flagWarungTepat;

    private Date tanggalBuat;

    Iterable<PembiayaanDTO> pembiayaan = new ArrayList<>();

    private long noRekening;

    private double saldo;

    private List<SetorTunai> setorTunais;

    private List<TarikTunai> tarikTunais;
}
