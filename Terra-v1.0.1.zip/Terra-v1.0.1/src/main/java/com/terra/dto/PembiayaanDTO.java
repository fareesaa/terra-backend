package com.terra.dto;

import com.terra.entity.Angsuran;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class PembiayaanDTO {

    private long id;

    private long nikKtp;

    private String nama;

    private long noPembiayaan;

    private int status;

    private long jumlahPembiayaan;

    private long jumlahHarusBayar;

    private long jumlahHarusBayarBulan;

    private Date tanggalPembiayaan;

    private int tenor;

    private List<Angsuran> angsurans;

}
