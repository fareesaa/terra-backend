package com.terra.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ResponseTarikTunaiDTO {

    private long nikKaryawan;

    private long nikKtp;

    private double nominalUpdate;

    private long noRekening;

    private LocalDateTime tanggal;
}
