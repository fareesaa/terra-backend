package com.terra.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class TransaksiDTO {

    private long nikKaryawan;

    private long nikKtp;

    private long nominal;

    private long noRekening;

//    private double nominalUpdate;
}
