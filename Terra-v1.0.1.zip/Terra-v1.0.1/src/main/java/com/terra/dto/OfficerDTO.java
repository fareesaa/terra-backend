package com.terra.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class OfficerDTO {

    private Long id;

    private long nikKaryawan;

    private long nikKtp;

    private String nama;

    private String email;

    private String password;

    private Date tanggalLahir;

    private String tempatLahir;

    private String alamat;

    private String jabatan;

    private String cabang;

    private int status;
//    @ManyToMany(mappedBy = "suppliers")
//    @JsonBackReference
//    private Set<Product> products;
}
