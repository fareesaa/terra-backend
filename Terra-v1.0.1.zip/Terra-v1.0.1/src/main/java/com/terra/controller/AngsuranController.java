package com.terra.controller;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.terra.dto.LoginDTO;
import com.terra.dto.PembiayaanDTO;
import com.terra.dto.ResponseData;
import com.terra.entity.Angsuran;
import com.terra.service.AngsuranService;
import com.terra.service.PembiayaanClientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.security.Key;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/client")
public class AngsuranController {

    @Autowired
    private  AngsuranService angsuranService;

    @Autowired
    private  PembiayaanClientService pembiayaanClientService;

    @GetMapping("/pembiayaan/{nopembiayaan}")
    public ResponseEntity<?> findNasabahObjectById(@PathVariable("nopembiayaan") long nopembiayaan){
        return new ResponseEntity<>(pembiayaanClientService.getPembiayaan(nopembiayaan).getPembiayaan(),HttpStatus.ACCEPTED);
    }

    @PostMapping("/angsuran")
    public ResponseEntity<?> postLogin(@RequestBody Angsuran request){

        PembiayaanDTO pembiayaanDTO = pembiayaanClientService.getPembiayaan(request.getNoPembiayaan()).getPembiayaan();
        Angsuran angsuran = angsuranService.bayarAngsuran(pembiayaanDTO, request);
        if (angsuran == null){
            pembiayaanDTO.setStatus(0);
            pembiayaanClientService.updatePembiayaan(pembiayaanDTO);
            return new ResponseEntity<>("Pencicilan telah lunas!"
                    , HttpStatus.OK);
        }
        pembiayaanClientService.updatePembiayaan(pembiayaanDTO);
        return new ResponseEntity<>(angsuran
                , HttpStatus.ACCEPTED);
    }
}
