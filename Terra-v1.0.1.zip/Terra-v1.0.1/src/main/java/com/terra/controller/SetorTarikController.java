package com.terra.controller;

import com.terra.dto.NasabahDTO;
import com.terra.dto.ResponseData;
import com.terra.dto.TransaksiDTO;
import com.terra.entity.SetorTunai;
import com.terra.entity.TarikTunai;
import com.terra.repository.SetorTunaiRepository;
import com.terra.service.SetorTarikTunaiClientService;
import com.terra.service.SetorTunaiService;
import com.terra.service.TarikTunaiService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/client")
public class SetorTarikController {

    @Autowired
    private SetorTarikTunaiClientService setorTarikTunaiClientService;

    @Autowired
    private TarikTunaiService tarikTunaiService;

    @Autowired
    private SetorTunaiService setorTunaiService;

//==============================================Get Nasabah By NIK=======================================================//

    @GetMapping("/nasabah/{nikKtp}")
    public ResponseEntity<?> findNasabahObjectById(@PathVariable("nikKtp") long nikKtp){
        return new ResponseEntity<>(setorTarikTunaiClientService.getNasabaObjectByNik(nikKtp).getNasabahDTO(), HttpStatus.ACCEPTED);
    }

    @PutMapping("/nasabah/setortunai/{nikKtp}")
    public ResponseEntity<?> setorTunaiNasabah(@PathVariable("nikKtp") long nikKtp, @RequestBody  TransaksiDTO request){
        NasabahDTO nasabahDTO = setorTarikTunaiClientService.getNasabaObjectByNik(nikKtp).getNasabahDTO();
        SetorTunai setorTunai = setorTunaiService.setorTunaiProspera(nasabahDTO,request);
        setorTarikTunaiClientService.updateSaldoNasabah(nikKtp, request);
        return new ResponseEntity<>(
                setorTarikTunaiClientService.responseTarikTunaiDTO(nasabahDTO,request), HttpStatus.ACCEPTED
        );
    }

    @PutMapping("/nasabah/tariktunai/{nikKtp}")
    public ResponseEntity<?> tarikTunaiNasabah(@PathVariable("nikKtp") long nikKtp, @RequestBody TransaksiDTO request){

        NasabahDTO nasabahDTO = setorTarikTunaiClientService.getNasabaObjectByNik(nikKtp).getNasabahDTO();
        TarikTunai tarikTunai = tarikTunaiService.tarikTunaiProcess(nasabahDTO, request);

        if(tarikTunai == null){
            return new ResponseEntity<>("Saldo tidak cukup!", HttpStatus.ACCEPTED);
        }
        setorTarikTunaiClientService.updateSaldoNasabah(nikKtp, request);
        return new ResponseEntity<>(
                setorTarikTunaiClientService.responseTarikTunaiDTO(nasabahDTO,request), HttpStatus.ACCEPTED
        );
    }


//================================================Mini Prospera=======================================================//

//@GetMapping("/nasabah/{nikKtp}")
//public ResponseEntity<?> findNasabahObjectById(@PathVariable("nikKtp") long nikKtp){
//        NasabahDTO nasabahDTO = setorTarikTunaiClientService.getNasabaObjectByNik(nikKtp);
////    Object obj = setorTarikTunaiClientService.getNasabaObjectByNik(nikKtp);
//    return new ResponseEntity<>(obj, HttpStatus.ACCEPTED);
//}

//    @PutMapping("/nasabah/setortunai/{nikCo}")
//    public ResponseEntity<?> setorTunaiNasabahProspera(@PathVariable("nikCo") long nikCo, @RequestBody TransaksiDTO request){
//
//        NasabahDTO nasabahDTO = setorTarikTunaiClientService.getNasabaObjectById(norek);
//        SetorTunai setorTunai = setorTunaiService.setorTunaiPrint(nasabahDTO, request, nikCo);
//        setorTarikTunaiClientService.updateSaldoNasabah(norek, nasabahDTO);
//        return new ResponseEntity<>(setorTunai, HttpStatus.ACCEPTED);
//    }

//    @PutMapping("/comments/{id}")
//    public ResponseEntity<Comment> updateComment(@PathVariable("id") long id, @RequestBody Comment commentRequest) {
//        Comment comment = commentRepository.findById(id)
//                .orElseThrow(/*() -> new ResourceNotFoundException("CommentId " + id + "not found")*/);
//
//        comment.setContent(commentRequest.getContent());
//
//        return new ResponseEntity<>(commentRepository.save(comment), HttpStatus.OK);
//    }
}
