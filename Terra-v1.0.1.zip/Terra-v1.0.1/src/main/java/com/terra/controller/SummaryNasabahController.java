package com.terra.controller;

import com.terra.dto.NasabahDTO;
import com.terra.dto.PembiayaanDTO;
import com.terra.dto.ResponseSummaryPinjaman;
import com.terra.entity.Angsuran;
import com.terra.entity.SetorTunai;
import com.terra.entity.TarikTunai;
import com.terra.repository.AngsuranRepository;
import com.terra.repository.SetorTunaiRepository;
import com.terra.repository.TarikTunaiRepository;
import com.terra.service.SetorTarikTunaiClientService;
import com.terra.service.SetorTunaiService;
import com.terra.service.TarikTunaiService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;

@RestController
@RequestMapping("/client")
public class SummaryNasabahController {
    @Autowired
    private SetorTarikTunaiClientService setorTarikTunaiClientService;

    @Autowired
    private TarikTunaiService tarikTunaiService;

    @Autowired
    private SetorTunaiService setorTunaiService;

    @Autowired
    private AngsuranRepository angsuranRepository;

    @Autowired
    private SetorTunaiRepository setorTunaiRepository;

    @Autowired
    private TarikTunaiRepository tarikTunaiRepository;

    @GetMapping("/nasabah/summary/pinjaman/{nikKtp}")
    public ResponseEntity<?> summaryPinjaman(@PathVariable("nikKtp") long nikKtp){
//        ResponseSummaryPinjaman responseSummaryPinjaman = new ResponseSummaryPinjaman();

        NasabahDTO nasabahDTO = setorTarikTunaiClientService.getNasabaObjectByNik(nikKtp).getNasabahDTO();
        PembiayaanDTO pembiayaanDTO = nasabahDTO.getPembiayaan().iterator().next();
        List<Angsuran> angsurans = new ArrayList<>();
        angsuranRepository.findByNoPembiayaan(pembiayaanDTO.getNoPembiayaan()).forEach(angsurans::add);
        pembiayaanDTO.setAngsurans(angsurans);


        return new ResponseEntity<>(nasabahDTO, HttpStatus.ACCEPTED);
    }

    @GetMapping("/nasabah/summary/tabungan/{nikKtp}")
    public ResponseEntity<?> summaryTabungan(@PathVariable("nikKtp") long nikKtp){
        NasabahDTO nasabahDTO = setorTarikTunaiClientService.getNasabaObjectByNik(nikKtp).getNasabahDTO();
        List<SetorTunai> setorTunaiList = new ArrayList<>();
        setorTunaiRepository.findByNorek(nasabahDTO.getNoRekening()).forEach(setorTunaiList::add);
        List<TarikTunai> tarikTunaiList = new ArrayList<>();
        tarikTunaiRepository.findByNorek(nasabahDTO.getNoRekening()).forEach(tarikTunaiList::add);
        nasabahDTO.setSetorTunais(setorTunaiList);
        nasabahDTO.setTarikTunais(tarikTunaiList);

        return new ResponseEntity<>(nasabahDTO, HttpStatus.ACCEPTED);
    }

}
