package com.terra.service;

import com.terra.dto.PembiayaanDTO;
import com.terra.dto.ResponseData;
import com.terra.dto.TransaksiDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class PembiayaanClientService {

    @Autowired
    private RestTemplate restTemplate;

    public ResponseData getPembiayaan(long noPembiayaan){
        ResponseData responseData = restTemplate.getForObject("http://192.168.1.9:8080/api/pembiayaan/terra/"+noPembiayaan, ResponseData.class);
        return responseData;
    }

    public PembiayaanDTO updatePembiayaan(PembiayaanDTO request){
        restTemplate.put("http://192.168.1.9:8080/api/pembiayaan/update/", request, PembiayaanDTO.class);
        return request;
    }
}
