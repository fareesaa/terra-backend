package com.terra.service;

import com.terra.dto.NasabahDTO;
import com.terra.dto.TransaksiDTO;
import com.terra.entity.SetorTunai;
import com.terra.entity.TarikTunai;
import com.terra.repository.TarikTunaiRepository;
import org.aspectj.lang.NoAspectBoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TarikTunaiService {
    @Autowired
    private TarikTunaiRepository tarikTunaiRepository;

    public TarikTunai tarikTunaiProcess(NasabahDTO nasabahDTO, TransaksiDTO transaksiDTO){

        TarikTunai tarikTunai = new TarikTunai();

        tarikTunai.setJumlahtarik(transaksiDTO.getNominal());
        tarikTunai.setNikkaryawan(transaksiDTO.getNikKaryawan());
        tarikTunai.setNorek(nasabahDTO.getNoRekening());
        tarikTunai.setTanggaltarik(java.time.LocalDateTime.now());

        if(nasabahDTO.getSaldo()< tarikTunai.getJumlahtarik()){
            return null;
        }
        tarikTunaiRepository.save(tarikTunai);

        String nom= "-"+ transaksiDTO.getNominal();
        long nominalan= Long.parseLong(nom);
        transaksiDTO.setNominal(nominalan);

        return tarikTunai;
    }
}
