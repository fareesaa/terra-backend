package com.terra.service;

import com.terra.dto.NasabahDTO;
import com.terra.dto.TransaksiDTO;
import com.terra.entity.SetorTunai;
import com.terra.repository.SetorTunaiRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SetorTunaiService {

    @Autowired
    private SetorTunaiRepository setorTunaiRepository;

//    public SetorTunai setorTunaiPrint(NasabahDTO nasabahDTO, SetorTunai setorTunai, long nikCo){
//        double saldoTerkini = nasabahDTO.getSaldo() + setorTunai.getJumlahsetor();
//        nasabahDTO.setSaldo(saldoTerkini);
//
//        setorTunai.setNorek(nasabahDTO.getNorek());
//        setorTunai.setNikkaryawan(nikCo);
////        DateTimeFormatter dtf= DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
////        LocalDateTime now= LocalDateTime.now();
//        setorTunai.setTanggalsetor(java.time.LocalDateTime.now());
//        setorTunaiRepository.save(setorTunai);
//        return setorTunai;
//    }

    public SetorTunai setorTunaiPrint(NasabahDTO nasabahDTO, SetorTunai setorTunai, long nikCo){
        double saldoTerkini = nasabahDTO.getSaldo() + setorTunai.getJumlahsetor();
        nasabahDTO.setSaldo(saldoTerkini);

        setorTunai.setNorek(nasabahDTO.getNikKtp());
        setorTunai.setNikkaryawan(nikCo);
//        DateTimeFormatter dtf= DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
//        LocalDateTime now= LocalDateTime.now();
        setorTunai.setTanggalsetor(java.time.LocalDateTime.now());
        setorTunaiRepository.save(setorTunai);
        return setorTunai;
    }

    public SetorTunai setorTunaiProspera(NasabahDTO nasabahDTO,TransaksiDTO transaksiDTO){

        SetorTunai setorTunai = new SetorTunai();
        setorTunai.setJumlahsetor(transaksiDTO.getNominal());
        setorTunai.setNorek(nasabahDTO.getNoRekening());
        setorTunai.setNikkaryawan(transaksiDTO.getNikKaryawan());
        setorTunai.setTanggalsetor(java.time.LocalDateTime.now());
        setorTunaiRepository.save(setorTunai);

        return setorTunai;
    }
}
