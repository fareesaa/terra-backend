package com.terra.service;

import com.terra.dto.NasabahDTO;
import com.terra.dto.PembiayaanDTO;
import com.terra.dto.ResponseAngsuran;
import com.terra.dto.TransaksiDTO;
import com.terra.entity.Angsuran;
import com.terra.repository.AngsuranRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class AngsuranService {

    @Autowired
    private SetorTarikTunaiClientService setorTarikTunaiClientService;

    @Autowired
    private SetorTunaiService setorTunaiService;

    @Autowired
    private AngsuranRepository angsuranRepository;


//    public List<Angsuran> getAllAngsuranByNoPembiayaan(long nopembiayaan){
//        angsuranRepository.findByNopembiayaan(nopembiayaan).forEach(tutorials::add);
//    }

    public Angsuran bayarAngsuran(PembiayaanDTO pembiayaanDTO, Angsuran request){

        double defaultAngsuran = pembiayaanDTO.getJumlahHarusBayar()/12 ;
        Angsuran angsuran = new Angsuran();
        ResponseAngsuran responseAngsuran = new ResponseAngsuran();

        if(pembiayaanDTO.getTenor()==0){
            return null;
        }

        if (request.getBayarangsuran() < pembiayaanDTO.getJumlahHarusBayarBulan()){
            double kurang = pembiayaanDTO.getJumlahHarusBayarBulan() - request.getBayarangsuran();
            double harusBayar = defaultAngsuran+kurang;
            pembiayaanDTO.setJumlahHarusBayarBulan(Double.valueOf(harusBayar).longValue());

            angsuran.setIdpembiayaan(pembiayaanDTO.getId());
            angsuran.setTanggalcicilan(LocalDateTime.now());
            angsuran.setBayarangsuran(request.getBayarangsuran());
            angsuran.setNikkaryawan(request.getNikkaryawan());
            angsuran.setNoPembiayaan(request.getNoPembiayaan());
            angsuranRepository.save(angsuran);

            responseAngsuran.setAngsuran(angsuran);
            responseAngsuran.setMessage("Pembayaran angsuran kurang, kekurangan akan dilimpahkan ke tenor selanjutnya.");

        } else if (request.getBayarangsuran() == pembiayaanDTO.getJumlahHarusBayarBulan()) {
            pembiayaanDTO.setJumlahHarusBayarBulan(Double.valueOf(defaultAngsuran).longValue());

            angsuran.setIdpembiayaan(pembiayaanDTO.getId());
            angsuran.setTanggalcicilan(LocalDateTime.now());
            angsuran.setBayarangsuran(request.getBayarangsuran());
            angsuran.setNikkaryawan(request.getNikkaryawan());
            angsuran.setNoPembiayaan(request.getNoPembiayaan());
            angsuranRepository.save(angsuran);
            
            responseAngsuran.setAngsuran(angsuran);
            responseAngsuran.setMessage("Pembayaran angsuran berhasil! ");

        } else if (request.getBayarangsuran() > pembiayaanDTO.getJumlahHarusBayarBulan()) {
            double lebih = request.getBayarangsuran() - pembiayaanDTO.getJumlahHarusBayarBulan();
            pembiayaanDTO.setJumlahHarusBayarBulan(Double.valueOf(defaultAngsuran).longValue());

            angsuran.setIdpembiayaan(pembiayaanDTO.getId());
            angsuran.setTanggalcicilan(LocalDateTime.now());
            angsuran.setBayarangsuran(request.getBayarangsuran());
            angsuran.setNikkaryawan(request.getNikkaryawan());
            angsuran.setNoPembiayaan(request.getNoPembiayaan());
            angsuranRepository.save(angsuran);

            TransaksiDTO transaksiDTO = new TransaksiDTO();
            NasabahDTO nasabahDTO = setorTarikTunaiClientService.getNasabaObjectByNik(pembiayaanDTO.getNikKtp()).getNasabahDTO();
            transaksiDTO.setNikKaryawan(request.getNikkaryawan());
            transaksiDTO.setNominal(Double.valueOf(lebih).longValue());
            transaksiDTO.setNoRekening(nasabahDTO.getNoRekening());
            transaksiDTO.setNikKtp(pembiayaanDTO.getNikKtp());
            setorTunaiService.setorTunaiProspera(nasabahDTO,transaksiDTO);
            setorTarikTunaiClientService.updateSaldoNasabah(pembiayaanDTO.getNikKtp(), transaksiDTO);

            responseAngsuran.setAngsuran(angsuran);
            responseAngsuran.setMessage
                    ("Pembayaran angsuran lebih dari kewajiban, dana yang berlebih akan di setor kedalam tabungan nasabah dengan nomor rekening"
                            + nasabahDTO.getNoRekening());
        }
        pembiayaanDTO.setTenor(pembiayaanDTO.getTenor()-1);
        return angsuran;
    }
}
