package com.terra.service;

import com.terra.dto.*;
import com.terra.setup.IpSet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class LoginClientService {

    @Autowired
    private RestTemplate restTemplate;

    public ResponseData loginCommunityOfficer(LoginDTO request){
        ResponseData responseData= restTemplate.postForObject(IpSet.ipset+":8080/login", request, ResponseData.class);
        return responseData;
    }
}
