package com.terra.service;

import com.terra.dto.NasabahDTO;
import com.terra.dto.ResponseData;
import com.terra.dto.ResponseTarikTunaiDTO;
import com.terra.dto.TransaksiDTO;
import com.terra.entity.TarikTunai;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDateTime;

@Service
public class SetorTarikTunaiClientService {
    @Autowired
    private RestTemplate restTemplate;


//===============================================Mini Prospera============================================================//

//    public NasabahDTO getNasabaObjectById(long id){
//        NasabahDTO nasabahDTO = restTemplate.getForObject("http://localhost:8081/nasabah/"+id, NasabahDTO.class);
//        return nasabahDTO;
//    }
    //Mini Prospera
//    public NasabahDTO updateSaldoNasabah1(long id, NasabahDTO request){
//        restTemplate.put("http://192.168.100.7:8080/update/nasabah/"+id, request, NasabahDTO.class);
//        return request;
//    }


//===============================================Prospera=================================================================//

    public ResponseData getNasabaObjectByNik(long nikKtp){
        ResponseData responseData = restTemplate.getForObject("http://192.168.1.9:8080/api/nasabah/terra/"+nikKtp, ResponseData.class);
        responseData.getNasabahDTO();
        return responseData;
    }

    public TransaksiDTO updateSaldoNasabah(long nikKtp, TransaksiDTO request){
        restTemplate.put("http://192.168.1.9:8080/api/tabungan/transaksi-saldo/"+nikKtp, request, TransaksiDTO.class);
        return request;
    }

    public TransaksiDTO updatePembiayaan(long nikKtp, TransaksiDTO request){
        restTemplate.put("http://192.168.1.9:8080/api/tabungan/transaksi-saldo/"+nikKtp, request, TransaksiDTO.class);
        return request;
    }

    public ResponseTarikTunaiDTO responseTarikTunaiDTO(NasabahDTO nasabahDTO, TransaksiDTO transaksiDTO){
        ResponseTarikTunaiDTO responseTarikTunaiDTO = new ResponseTarikTunaiDTO();

        responseTarikTunaiDTO.setNikKaryawan(transaksiDTO.getNikKaryawan());
        responseTarikTunaiDTO.setNominalUpdate(nasabahDTO.getSaldo()+transaksiDTO.getNominal());
        responseTarikTunaiDTO.setNikKtp(transaksiDTO.getNikKtp());
        responseTarikTunaiDTO.setNoRekening(nasabahDTO.getNoRekening());
        responseTarikTunaiDTO.setTanggal(LocalDateTime.now());
        return responseTarikTunaiDTO;
    }
}
