package com.terra.repository;

import com.terra.entity.SetorTunai;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SetorTunaiRepository extends JpaRepository<SetorTunai, Long> {

    List<SetorTunai> findByNorek(long norek);
}
