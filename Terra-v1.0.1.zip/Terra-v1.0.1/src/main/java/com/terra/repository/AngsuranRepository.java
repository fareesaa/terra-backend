package com.terra.repository;

import com.terra.entity.Angsuran;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AngsuranRepository extends JpaRepository<Angsuran, Long> {

    List<Angsuran> findByNoPembiayaan(long nopembiayaan);

}
