package com.terra.repository;

import com.terra.entity.SetorTunai;
import com.terra.entity.TarikTunai;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TarikTunaiRepository extends JpaRepository<TarikTunai, Long> {

    List<TarikTunai> findByNorek(long norek);

}
