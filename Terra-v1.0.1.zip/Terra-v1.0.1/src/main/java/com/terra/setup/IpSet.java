package com.terra.setup;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.ToString;
@Data
@AllArgsConstructor
@ToString
//================================================== SET YOUR IP HERE ====================================================//
public class IpSet {
    public static String  ipset = "http://192.168.1.9";
}